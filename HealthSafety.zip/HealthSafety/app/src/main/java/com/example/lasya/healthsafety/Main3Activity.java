package com.example.lasya.healthsafety;

import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
SQLiteDatabase db;
EditText e1,e2,e3,e4,e5,e6,e7,e8,e9,e10,e11,e12,e13,e14,e15;
Button b;
  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        e1=findViewById(R.id.editText8);
      e2=findViewById(R.id.editText9);
      e3=findViewById(R.id.editText10);
      e4=findViewById(R.id.editText11);
      e5=findViewById(R.id.editText12);
      e6=findViewById(R.id.editText13);
      e7=findViewById(R.id.editText14);
      e8=findViewById(R.id.editText15);
      e9=findViewById(R.id.editText16);
      e10=findViewById(R.id.editText17);
      e11=findViewById(R.id.editText18);
      e12=findViewById(R.id.editText19);
      e13=findViewById(R.id.editText20);
      e14=findViewById(R.id.editText21);
      e15=findViewById(R.id.editText22);
      b=findViewById(R.id.button4);
      db=openOrCreateDatabase("KLU",MODE_PRIVATE,null);

      db.execSQL("CREATE TABLE IF NOT EXISTS Club(name1 varchar(30),phno1 number(15),email1 varchar(30),name2 varchar(30),phno2 number(15),email2 varchar(30),name3 varchar(30),phno3 number(15),email3 varchar(30),name4 varchar(30),phno4 number(15),email4 varchar(30),name5 varchar(30),phno5 number(15),email5 varchar(30));");
      b.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String name1=e1.getText().toString();
              String phno1=e2.getText().toString();
              String email1=e3.getText().toString();
              String name2=e4.getText().toString();
              String phno2=e5.getText().toString();
              String email2=e6.getText().toString();
              String name3=e7.getText().toString();
              String phno3=e8.getText().toString();
              String email3=e9.getText().toString();
              String name4=e10.getText().toString();
              String phno4=e11.getText().toString();
              String email4=e12.getText().toString();
              String name5=e13.getText().toString();
              String phno5=e14.getText().toString();
              String email5=e15.getText().toString();
              db.execSQL("INSERT INTO Club values('"+name1+"','"+phno1+"','"+email1+"','"+name2+"','"+phno2+"','"+email2+"','"+name3+"','"+phno3+"','"+email3+"','"+name4+"','"+phno4+"','"+email4+"','"+name5+"','"+phno5+"','"+email5+"');");
              Toast.makeText(Main3Activity.this, "ADDED", Toast.LENGTH_SHORT).show();

          }
      });


    }
}
