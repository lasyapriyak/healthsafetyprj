package com.example.lasya.healthsafety;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

public class disp extends AppCompatActivity {

    ListView datalist;
    List<String> lst;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disp);
        datalist = findViewById(R.id.listt);
        lst = new ArrayList<>();

        db = openOrCreateDatabase("KLU",MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Club(name1 varchar(30),phno1 number(15),email1 varchar(30),name2 varchar(30),phno2 number(15),email2 varchar(30),name3 varchar(30),phno3 number(15),email3 varchar(30),name4 varchar(30),phno4 number(15),email4 varchar(30),name5 varchar(30),phno5 number(15),email5 varchar(30));");

        Cursor c = db.rawQuery("select * from Club",null);

        while (c.moveToNext())
        {
            String s = "Name: "+ c.getString(0)+"\nPhno: "+c.getString(1)+"\nEmailid: "+c.getString(2)+"\n\nName: "+ c.getString(3)+"\nPhno: "+c.getString(4)+"\nEmailid: "+c.getString(5)+"\n\nName: "+ c.getString(6)+"\nPhno: "+c.getString(7)+"\nEmailid: "+c.getString(8)+"\n\nName: "+ c.getString(9)+"\nPhno: "+c.getString(10)+"\nEmailid: "+c.getString(11)+"\n\nName: "+ c.getString(12)+"\nPhno: "+c.getString(13)+"\nEmailid: "+c.getString(14);
            lst.add(s);
        }
        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,lst);

        datalist.setAdapter(arrayAdapter);

    }
}